
SHOUTBOX GROUP
===================

Shoutbox Group is a simple integration between Shoutbox and Organic Groups.

When enabled, if a shoutbox block appears within a group context, the shouts shown
will only be shouts that were made within that group. If you view the block outside
of a group, only general shouts will show (optional via the admin settings).

This provides a shoutbox environment specific for every group on the site.

Groups will also have a dedicated shoutbox page which is linked to via the standard
group details block that is provided with Organic groups. A link will also be provided
in the footer of the block.
